
<div class="row">

  <div class="col-md-12">
    <div class="card">
      <div class="header">
        <h4 class="title">Dashboard</h4>
      </div>
      <div class="content">
        <p>Sistem Informasi V 0.1</p>
        <p>Fitur : </p>
        <ul>
          <li>Pemesanan Kamar</li>
          <li>Pembayaran</li>
          <li>Melihat seluruh histori pemesanan</li>
        </ul>
      </div>
    </div>
  </div>
</div>
</div>
