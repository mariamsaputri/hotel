</body>
<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

<script src="assets/js/bootstrap-checkbox-radio.js"></script>

<script src="assets/js/chartist.min.js"></script>
<script src="assets/js/bootstrap-notify.js"></script>

<script src="assets/js/paper-dashboard.js"></script>
<script src="assets/js/pemesanan.js" charset="utf-8"></script>

<?php if (isset($include_js)): ?>
  <script>
 <?php echo $include_js . "\n";?>
</script>
<?php endif; ?>
</html>
