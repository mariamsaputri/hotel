<?php

$databaseHost = 'localhost';
$databaseName = 'simho';
$databaseUsername = 'root';
$databasePassword = '';
$connect = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);

?>
