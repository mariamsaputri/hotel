<footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">

                </nav>
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> SIMHO - <a href="http://bobbyfiando.com">Bobby Fiando Sadela</a>, theme by <a href="http://www.creative-tim.com">Creative Tim</a>
                </div>
            </div>
</footer>
