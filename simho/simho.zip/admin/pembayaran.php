<?php include_once('lib/header.php'); ?>
<div class="wrapper">
    <?php include_once('lib/sidebar.php'); ?>
    <div class="main-panel">
    <?php include_once('lib/navbar.php'); ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <?php include_once('content/pembayaran.php'); ?>
                </div>
            </div>
        </div>

    <?php include_once("lib/footer-top.php"); ?>
    
    </div>
</div>

<?php include_once('lib/footer.php'); ?>