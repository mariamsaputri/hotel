
<div class="row">

  <div class="col-md-12">
    <div class="card">
      <div class="header">
        <h4 class="title">Tipe kamar</h4>
      </div>
      <div class="content">
        <p>Sistem Informasi</p>
        <p>Fitur : </p>
        <ul>
          <li>Pemesanan Kamar</li>
          <li>Pembayaran</li>
        </ul>
      </div>
    </div>
  </div>
</div>
</div>
<div class="row">
  <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
      <img src="assets/img/basic.jpg" alt="...">
      <div class="caption">
        <h3>Tipe Kamar Basic</h3>
        <p>Rp.250000</p>
        <p><a href="pelanggan.php" class="btn btn-primary" role="button">Booking</a></p>
      </div>
    </div>
  </div>

  <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
      <img src="assets/img/premium - Copyy.jpg" alt="...">
      <div class="caption">
        <h3>Tipe Kamar Premium</h3>
        <p>Rp.500000</p>
        <p><a href="pelanggan.php" class="btn btn-primary" role="button">Booking</a></p>
      </div>
    </div>
  </div>

  <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
      <img src="assets/img/grand.jpeg" alt="...">
      <div class="caption">
        <h3>Tipe Kamar Grand</h3>
        <p>Rp.750000</p>
        <p><a href="pelanggan.php" class="btn btn-primary" role="button">Booking</a></p>
      </div>
    </div>
  </div>
</div>

<div class="row">
<div class="col-sm-6 col-md-4">
    <div class="thumbnail">
      <img src="assets/img/royal.jpg" alt="...">
      <div class="caption">
        <h3>Tipe Kamar Royal</h3>
        <p>Rp.1000000</p>
        <p><a href="pelanggan.php" class="btn btn-primary" role="button">Booking</a></p>
      </div>
    </div>
  </div>
</div>
